package com.baliraja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BalirajaApplicationTests {

	@Test
	void contextLoads() {
	}

}
