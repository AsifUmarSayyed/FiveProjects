import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-government',
  templateUrl: './government.component.html',
  styleUrls: ['./government.component.scss']
})
export class GovernmentComponent implements OnInit {

  constructor(){ }

  ngOnInit(): void {
  }

}
