import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactsupplier',
  templateUrl: './contactsupplier.component.html',
  styleUrls: ['./contactsupplier.component.scss']
})
export class ContactsupplierComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
