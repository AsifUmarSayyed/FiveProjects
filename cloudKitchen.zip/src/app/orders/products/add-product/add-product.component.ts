import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss'],
})
export class AddProductComponent implements OnInit {
  constructor(private productService: ProductService) {}

  ngOnInit(): void {}
  // addNewProduct(form) {
  //   console.log(form.value);
  //  let newProduct={
  //     Id:101,
  //     category_id:form.value.

  //   }
  // }
}
