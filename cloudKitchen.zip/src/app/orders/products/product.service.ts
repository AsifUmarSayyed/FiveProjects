import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Category } from 'src/app/site-layout/Category';
import { Product } from './product';
@Injectable({
  providedIn: 'root',
})
export class ProductService {
  constructor(private httpClient: HttpClient) {}
  createProduct(productBody: Observable<Product>) {
    const baseUrl = 'http:/localhost:3000/product';
    return this.httpClient.post<Product>(baseUrl, productBody);
  }
  viewProduct(): Observable<Product> {
    const baseUrl = 'http://localhost:3000/product/';
    return this.httpClient.get<Product>(baseUrl);
  }
  viewSingleProduct(productId: Observable<Product>) {
    const baseUrl = 'http://localhost:3000/product?id=' + productId;
    return this.httpClient.get<Product>(baseUrl);
  }
  updateProduct(
    productId: Observable<Product>,
    productBody: Observable<Product>
  ) {
    const baseUrl = 'http:/localhost:3000/product/' + productId;
    return this.httpClient.put<Product>(baseUrl, productBody);
  }
  deleteProduct(productId: Observable<Product>) {
    const baseUrl = 'http:/localhost:3000/product/' + productId;
    return this.httpClient.delete<Product>(baseUrl);
  }
  searchCategoryProduct(categoryId: Observable<Product>) {
    const baseUrl = 'http://localhost:3000/product?category_id=' + categoryId;
    return this.httpClient.get<Product>(baseUrl);
  }
  searchDateProduct(dateParam: Observable<Product>) {
    const baseUrl = 'http:/localhost:3000/product/date=' + dateParam;
    return this.httpClient.get<Product>(baseUrl);
  }
  getCategory() {
    const categoryUrl = 'http://localhost:3000/categories';
    return this.httpClient.get<Category>(categoryUrl);
  }
  viewCategory(categoryId: Observable<Product>) {
    const categoryUrl = 'http://localhost:3000/categories?id=' + categoryId;
    return this.httpClient.get<Category>(categoryUrl);
  }
}
