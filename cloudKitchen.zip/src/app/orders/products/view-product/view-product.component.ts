import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-view-product',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.scss'],
})
export class ViewProductComponent implements OnInit {
  productId: any;
  productData: any;
  constructor(
    private activatedRoute: ActivatedRoute,
    private productService: ProductService
  ) {}
  ngOnInit(): void {
    this.activatedRoute.params.subscribe((data) => {
      this.productId = data;
      console.log(data);
    });
    this.productService
      .viewSingleProduct(this.productId.id)
      .subscribe((data) => {
        this.productData = data;
        console.log(data);
      });
  }
}
