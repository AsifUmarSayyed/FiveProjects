export interface Category {
   id:string,      
   categoryName:string,
      
}
